import time
import socket
import os
import sys
import re
import subprocess
import json
from datetime import datetime

try:
    from luma.core.interface.serial import i2c
    from luma.oled.device import ssd1306
    from luma.core.render import canvas
    from PIL import ImageFont, ImageDraw, Image
except ImportError:
    sys.exit(1)

# Configuration
CONFIG_FILE = "/etc/digi-gate/config.json"
I2C_ADDRESS = 0x3C
UPDATE_INTERVAL = 0.25

def load_config():
    defaults = {"callsign": "MYCALL", "node": "1234", "rotation": 0}
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                defaults.update(config)
                return defaults
        except: pass
    return defaults

CONFIG = load_config()
CALLSIGN = CONFIG["callsign"]
NODE_NUMBER = CONFIG["node"]
ROTATION = CONFIG["rotation"]

def get_ip_address():
    try:
        ips = subprocess.check_output(['hostname', '-I']).decode('utf-8').strip().split()
        for ip in ips:
            if not ip.startswith('172.') and not ip.startswith('169.') and not ip.startswith('10.8.'):
                return ip
        return ips[0] if ips else None
    except: return None

def get_wifi_strength():
    try:
        with open("/proc/net/wireless", "r") as f:
            lines = f.readlines()
            for line in lines:
                if 'wlan' in line:
                    parts = line.split()
                    qual = int(parts[2].replace('.', ''))
                    if qual <= 70: return int((qual / 70.0) * 100)
                    return qual
    except: pass
    return 0

def is_asterisk_ready():
    try:
        out = subprocess.check_output(['sudo', 'asterisk', '-rx', f'rpt xnode {NODE_NUMBER}'], stderr=subprocess.STDOUT, timeout=1).decode('utf-8')
        return "RPT_ALINKS" in out
    except: return False

def get_node_status():
    is_rx, is_tx, remotes = False, False, []
    try:
        out = subprocess.check_output(['sudo', 'asterisk', '-rx', f'rpt xnode {NODE_NUMBER}'], timeout=1.5).decode('utf-8')
        if "RPT_TXKEYED=1" in out: is_tx = True
        if "RPT_RXKEYED=1" in out: is_rx = True
        match = re.search(r"RPT_ALINKS=(.*)", out)
        if match:
            links_str = match.group(1).strip()
            parts = links_str.split(',')
            if len(parts) > 1:
                for entry in parts[1:]:
                    if len(entry) > 2:
                        node_id = entry[:-2]
                        if entry[-1] == 'K': is_rx = True
                        remotes.append(node_id)
    except: pass
    return is_rx, is_tx, remotes

def draw_wifi_bars(draw, strength):
    x_base, y_base = 112, 10
    num_bars = 5 if strength > 80 else 4 if strength > 60 else 3 if strength > 40 else 2 if strength > 20 else 1 if strength > 5 else 0
    for i in range(5):
        bar_h = (i + 1) * 2
        x, y = x_base + (i * 3), y_base - bar_h
        if i < num_bars: draw.rectangle((x, y, x + 1, y_base), fill="white")
        else: draw.point((x, y_base), fill="white")

def main(device):
    scroll_pos = 0
    # Screensaver state
    ss_x, ss_y = 10, 10
    ss_dx, ss_dy = 3, 2
    ss_nx, ss_ny = 50, 40
    ss_ndx, ss_ndy = -2, 3
    last_activity = time.time()
    SS_TIMEOUT = 30  # Seconds before screensaver kicks in

    while True:
        ip = get_ip_address() or "No IP"
        asl_ready = is_asterisk_ready()
        
        rx, tx, remotes = False, False, []
        if asl_ready:
            rx, tx, remotes = get_node_status()
        
        # Wake up on activity
        if rx or tx or not asl_ready:
            last_activity = time.time()
        
        with canvas(device) as draw:
            if not asl_ready:
                # Cleaner loading screen
                draw.text((20, 10), "SYSTEM STARTING", fill="white")
                draw.text((10, 30), f"IP: {ip}", fill="white")
                draw.text((20, 50), "Loading ASL...", fill="white")
            elif time.time() - last_activity > SS_TIMEOUT:
                # Screensaver Mode: Single bouncing text to prevent burn-in
                ss_text = "TORUN DIGI GATE V2.0"
                draw.text((ss_x, ss_y), ss_text, fill="white")
                ss_x += ss_dx
                ss_y += ss_dy
                if ss_x <= 0 or ss_x >= 15: ss_dx = -ss_dx
                if ss_y <= 0 or ss_y >= 50: ss_dy = -ss_dy
            else:
                # Redesigned Normal Mode
                now = datetime.now()
                wifi = get_wifi_strength()
                
                # Top Row: Date/Time and WiFi
                draw.text((0, 0), now.strftime('%d/%m/%Y %H:%M'), fill="white")
                draw_wifi_bars(draw, wifi)
                
                # Middle Row: Prominent Callsign and Node
                info = f"{CALLSIGN}  {NODE_NUMBER}"
                left, top, right, bottom = draw.textbbox((0, 0), info)
                draw.text(((128-(right-left))//2, 15), info, fill="white")
                
                # IP Address
                draw.text((0, 28), f"IP: {ip}", fill="white")
                
                # Status Indication
                if tx: 
                    status_text = " TRANSMITTING "
                    draw.rectangle((0, 40, 127, 52), outline="white", fill="white")
                    l, t, r, b = draw.textbbox((0, 0), status_text)
                    draw.text(((128-(r-l))//2, 41), status_text, fill="black")
                elif rx:
                    status_text = " RECEIVING "
                    draw.rectangle((0, 40, 127, 52), outline="white", fill="white")
                    l, t, r, b = draw.textbbox((0, 0), status_text)
                    draw.text(((128-(r-l))//2, 41), status_text, fill="black")
                else:
                    status_text = "IDLE"
                    l, t, r, b = draw.textbbox((0, 0), status_text)
                    draw.text(((128-(r-l))//2, 40), status_text, fill="white")

                # Scrolling Connected Nodes (Links)
                node_str = "Links: " + (", ".join(remotes) if remotes else "None")
                if len(node_str) > 21:
                    display_nodes = (node_str + "   " + node_str)[scroll_pos:scroll_pos + 21]
                    scroll_pos = (scroll_pos + 1) % (len(node_str) + 3)
                else:
                    display_nodes = node_str
                draw.text((0, 54), display_nodes, fill="white")
                
        time.sleep(UPDATE_INTERVAL)

if __name__ == "__main__":
    serial = i2c(port=1, address=I2C_ADDRESS)
    device = ssd1306(serial, rotation=ROTATION)
    main(device)
