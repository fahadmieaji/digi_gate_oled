import time
import socket
import os
import sys
import re
import subprocess
import json
from datetime import datetime

try:
    from luma.core.interface.serial import i2c
    from luma.oled.device import ssd1306
    from luma.core.render import canvas
    from PIL import ImageFont, ImageDraw, Image
except ImportError:
    sys.exit(1)

# Configuration
CONFIG_FILE = "/etc/digi-gate/config.json"
I2C_ADDRESS = 0x3C
UPDATE_INTERVAL = 0.25

def load_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                return config.get("callsign", "MYCALL"), config.get("node", "1234")
        except: pass
    return "MYCALL", "1234"

CALLSIGN, NODE_NUMBER = load_config()

def get_ip_address():
    try:
        ips = subprocess.check_output(['hostname', '-I']).decode('utf-8').strip().split()
        for ip in ips:
            if not ip.startswith('172.') and not ip.startswith('169.') and not ip.startswith('10.8.'):
                return ip
        return ips[0] if ips else None
    except: return None

def get_wifi_strength():
    try:
        with open("/proc/net/wireless", "r") as f:
            lines = f.readlines()
            for line in lines:
                if 'wlan' in line:
                    parts = line.split()
                    qual = int(parts[2].replace('.', ''))
                    if qual <= 70: return int((qual / 70.0) * 100)
                    return qual
    except: pass
    return 0

def is_asterisk_ready():
    try:
        out = subprocess.check_output(['sudo', 'asterisk', '-rx', f'rpt xnode {NODE_NUMBER}'], stderr=subprocess.STDOUT, timeout=1).decode('utf-8')
        return "RPT_ALINKS" in out
    except: return False

def get_node_status():
    is_rx, is_tx, remotes = False, False, []
    try:
        out = subprocess.check_output(['sudo', 'asterisk', '-rx', f'rpt xnode {NODE_NUMBER}'], timeout=1.5).decode('utf-8')
        if "RPT_TXKEYED=1" in out: is_tx = True
        if "RPT_RXKEYED=1" in out: is_rx = True
        match = re.search(r"RPT_ALINKS=(.*)", out)
        if match:
            links_str = match.group(1).strip()
            parts = links_str.split(',')
            if len(parts) > 1:
                for entry in parts[1:]:
                    if len(entry) > 2:
                        node_id = entry[:-2]
                        if entry[-1] == 'K': is_rx = True
                        remotes.append(node_id)
    except: pass
    return is_rx, is_tx, remotes

def draw_wifi_bars(draw, strength):
    x_base, y_base = 112, 10
    num_bars = 5 if strength > 80 else 4 if strength > 60 else 3 if strength > 40 else 2 if strength > 20 else 1 if strength > 5 else 0
    for i in range(5):
        bar_h = (i + 1) * 2
        x, y = x_base + (i * 3), y_base - bar_h
        if i < num_bars: draw.rectangle((x, y, x + 1, y_base), fill="white")
        else: draw.point((x, y_base), fill="white")

def main(device):
    scroll_pos = 0
    idle_messages = ["TORUN", "DiGi Gate V2", "www.torun.com.bd", "Made in Bangladesh"]
    while True:
        ip = get_ip_address()
        asl_ready = is_asterisk_ready()
        with canvas(device) as draw:
            if not asl_ready:
                if not ip: draw.text((45, 25), "TORUN", fill="white")
                else:
                    draw.text((45, 10), "TORUN", fill="white")
                    draw.text((10, 30), f"IP: {ip}", fill="white")
                    draw.text((25, 50), "Loading ASL...", fill="white")
            else:
                now = datetime.now()
                wifi = get_wifi_strength()
                rx, tx, remotes = get_node_status()
                if tx: status_text, is_active = " TRANSMITTING ", True
                elif rx: status_text, is_active = " RECEIVING ", True
                else:
                    status_text = idle_messages[(int(time.time()) // 3) % len(idle_messages)]
                    is_active = False
                draw.text((0, 0), f"{now.strftime('%d/%m/%Y %H:%M')}", fill="white")
                draw_wifi_bars(draw, wifi)
                draw.text((0, 13), f"{CALLSIGN} {NODE_NUMBER}", fill="white")
                draw.text((0, 26), f"IP: {ip}", fill="white")
                left, top, right, bottom = draw.textbbox((0, 0), status_text)
                w = right - left
                if is_active:
                    draw.rectangle((0, 39, 127, 51), outline="white", fill="white")
                    draw.text(((128-w)//2, 40), status_text, fill="black")
                else: draw.text(((128-w)//2, 39), status_text, fill="white")
                
                # Sliding logic for nodes
                node_str = "Nodes: " + (", ".join(remotes) if remotes else "No Links")
                if len(remotes) >= 2 or len(node_str) > 21:
                    display_nodes = (node_str + " | " + node_str)[scroll_pos:scroll_pos + 21]
                    scroll_pos = (scroll_pos + 1) % (len(node_str) + 3)
                else:
                    display_nodes = node_str
                draw.text((0, 53), display_nodes, fill="white")
        time.sleep(UPDATE_INTERVAL)

if __name__ == "__main__":
    serial = i2c(port=1, address=I2C_ADDRESS)
    main(ssd1306(serial))
