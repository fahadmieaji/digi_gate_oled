#!/usr/bin/env python3
import json
import os
import sys
import subprocess

CONFIG_FILE = "/etc/digi-gate/config.json"

def load_config():
    defaults = {"callsign": "MYCALL", "node": "1234", "rotation": 0}
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                config = json.load(f)
                defaults.update(config)
                return defaults
        except: pass
    return defaults

def save_config(config):
    try:
        os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
        with open(CONFIG_FILE, "w") as f:
            json.dump(config, f, indent=4)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

def restart_service():
    print("Restarting Digi-Gate service...")
    try:
        subprocess.run(["sudo", "systemctl", "restart", "digi-gate.service"], check=True)
        print("Service restarted successfully.")
    except Exception as e:
        print(f"Failed to restart service: {e}")

def main_menu():
    config = load_config()
    
    while True:
        os.system('clear')
        print("====================================")
        print("   DiGi Gate V2 Configuration Menu  ")
        print("====================================")
        print(f" 1. Change Callsign    (Current: {config['callsign']})")
        print(f" 2. Change Node Number (Current: {config['node']})")
        print(f" 3. Toggle Rotation    (Current: {'Inverted' if config['rotation'] == 2 else 'Normal'})")
        print(" 4. Save and Apply")
        print(" 5. Exit without saving")
        print("====================================")
        
        choice = input("Select an option (1-5): ")
        
        if choice == '1':
            new_call = input("Enter new Callsign: ").upper().strip()
            if new_call:
                config['callsign'] = new_call
        elif choice == '2':
            new_node = input("Enter new Node Number: ").strip()
            if new_node:
                config['node'] = new_node
        elif choice == '3':
            config['rotation'] = 2 if config['rotation'] == 0 else 0
            print(f"Rotation set to: {'Inverted' if config['rotation'] == 2 else 'Normal'}")
            input("Press Enter to continue...")
        elif choice == '4':
            if save_config(config):
                print("Configuration saved.")
                restart_service()
                input("Press Enter to return to menu...")
            else:
                input("Press Enter to return to menu...")
        elif choice == '5':
            print("Exiting...")
            break
        else:
            print("Invalid choice. Try again.")
            time.sleep(1)

if __name__ == "__main__":
    if os.geteuid() != 0:
        print("Please run this script as root (use sudo).")
        sys.exit(1)
    
    try:
        import time
        main_menu()
    except KeyboardInterrupt:
        print("\nExiting...")
        sys.exit(0)
